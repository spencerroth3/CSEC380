<?php

if("admin" == $_POST["username"] && "4dM1n!" == $_POST["password"]){
    header('Location: 1.jpg');	 
    exit;
} 
else{
    header('Location: 2.jpg');
    exit;
}

?>

